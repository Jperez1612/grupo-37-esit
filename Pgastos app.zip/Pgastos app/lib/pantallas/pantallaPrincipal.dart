import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../modelo/gasto.dart';
import '../db/database.dart';
import 'pantalla_editar_gasto.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Expense> _expenses = [];
  double _totalAmount = 0.0;

  @override
  void initState() {
    super.initState();
    _loadExpenses();
  }

  Future<void> _loadExpenses() async {
    final data = await DatabaseHelper.instance.getExpenses();
    double total = 0.0;
    for (var expense in data) {
      total += expense.amount;
    }
    setState(() {
      _expenses = data;
      _totalAmount = total;
    });
  }

 void _openEditScreen([Expense? expense]) async {
    final result = await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => EditExpenseScreen(expense: expense),
      ),
    );
    if (result == true) _loadExpenses();
  }

  Future<void> _deleteExpense(int id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmar eliminación'),
        content: const Text('¿Desea continuar con la eliminación de este gasto?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('No'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Sí'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await DatabaseHelper.instance.deleteExpense(id);
      await _loadExpenses();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Control de Gastos'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Divider(height: 1, thickness: 1),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            alignment: Alignment.centerRight,
            child: RichText(
              textAlign: TextAlign.right,
              text: TextSpan(
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black, // Asegura que todo tenga color definido
                ),
                children: [
                  const TextSpan(text: 'Total Gastado: ', 
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        TextSpan(
                          text: '\$${_totalAmount.toStringAsFixed(2)}',
                          style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold,
                          color: Colors.red, // Color del monto
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: _expenses.isEmpty
                ? const Center(child: Text('No hay gastos registrados.'))
                : ListView.builder(
                    itemCount: _expenses.length,
                    itemBuilder: (context, index) {
                      final expense = _expenses[index];
                      final dateFormatted = DateFormat('yyyy-MM-dd')
                          .format(DateTime.parse(expense.date));

                      return Card(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        child: ListTile(
                          title: Text(expense.title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
                          subtitle: RichText(
                            text: TextSpan(
                              style: DefaultTextStyle.of(context).style,
                              children: [
                                TextSpan(text: 'Fecha: $dateFormatted\n',),
                                TextSpan(text: 'Monto: '),
                                TextSpan(
                                  text: '\$${expense.amount.toStringAsFixed(2)}',
                                  style: const TextStyle(
                                    color: Colors.red, // Cambia el color aquí
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'edit') {
                                _openEditScreen(expense);
                              } else if (value == 'delete') {
                                _deleteExpense(expense.id!);
                              }
                            },
                            itemBuilder: (context) => [
                              const PopupMenuItem(
                                  value: 'edit', child: Text('Editar')),
                              const PopupMenuItem(
                                  value: 'delete', child: Text('Eliminar')),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton( 
        backgroundColor: Colors.green,
        onPressed: _openEditScreen,
        child:  Icon(Icons.add, color: Colors.black,),
      ),
      
    );
  }
}